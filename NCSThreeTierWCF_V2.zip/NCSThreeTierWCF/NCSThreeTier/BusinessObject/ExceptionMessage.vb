﻿Imports System.Runtime.Serialization

Namespace BussinessObjects
    <Serializable>
    <DataContract>
    Public Class ExceptionMessage
        Private infoExceptionMessage As String

        Public Sub New(ByVal Message As String)
            Me.infoExceptionMessage = Message
        End Sub

        <DataMember>
        Public Property errorMessageOfAction As String
            Get
                Return Me.infoExceptionMessage
            End Get
            Set(ByVal value As String)
                Me.infoExceptionMessage = value
            End Set
        End Property
    End Class
End Namespace