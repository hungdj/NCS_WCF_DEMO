﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Runtime.Serialization
Imports System.Text

Namespace BussinessObjects
    Public Class ClinicBO
        Private _ID As String
        Private _Name As String
        Private _NRIC As String
        Private _DateOfBirth As String
        Private _PhoneNumber As String
        Private _Picture As String
        Private _Address As String

        Public Property ID As String
            Get
                Return _ID
            End Get
            Set(ByVal value As String)
                _ID = value
            End Set
        End Property

        Public Property Name As String
            Get
                Return _Name
            End Get
            Set(ByVal value As String)
                _Name = value
            End Set
        End Property

        Public Property NRIC As String
            Get
                Return _NRIC
            End Get
            Set(ByVal value As String)
                _NRIC = value
            End Set
        End Property

        Public Property DateOfBirth As String
            Get
                Return _DateOfBirth
            End Get
            Set(ByVal value As String)
                _DateOfBirth = value
            End Set
        End Property

        Public Property PhoneNumber As String
            Get
                Return _PhoneNumber
            End Get
            Set(ByVal value As String)
                _PhoneNumber = value
            End Set
        End Property

        Public Property Picture As String
            Get
                Return _Picture
            End Get
            Set(ByVal value As String)
                _Picture = value
            End Set
        End Property

        Public Property Address As String
            Get
                Return _Address
            End Get
            Set(ByVal value As String)
                _Address = value
            End Set
        End Property

    End Class

End Namespace
