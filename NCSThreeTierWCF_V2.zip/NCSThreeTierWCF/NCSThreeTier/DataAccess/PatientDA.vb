﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports BusinessObject.BussinessObjects
Imports System.ServiceModel
Imports Z.Expressions

Namespace DataAccess
    Public Class PatientDA
        Private con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("NCS_IHISConnectionString").ToString())

        Public Function GetPatients_List() As List(Of PatientBO)
            Dim patientList As List(Of PatientBO) = New List(Of PatientBO)()
            Dim resourceTable As DataTable = New DataTable()
            Dim resultReader As SqlDataReader = Nothing
            Dim command As SqlCommand = New SqlCommand("GetPatient", con)
            command.CommandType = CommandType.StoredProcedure

            Try
                con.Open()
                resultReader = command.ExecuteReader()
                resourceTable.Load(resultReader)
                resultReader.Close()
                con.Close()
                patientList = (From dr In resourceTable.Rows Select New PatientBO() With {
            .ID = Convert.ToInt64(dr("ID")),
            .Name = dr("Name").ToString(),
            .NRIC = dr("NRIC").ToString(),
            .DateOfBirth = dr("DateOfBirth").ToString(),
            .PhoneNumber = dr("PhoneNumber").ToString(),
            .Picture = dr("Picture").ToString(),
            .Address = dr("Address").ToString()
        }).ToList()
            Catch exception As Exception

                If resultReader IsNot Nothing OrElse con.State = ConnectionState.Open Then
                    resultReader.Close()
                    con.Close()
                End If
            End Try

            Return patientList
        End Function

        Public Function GetPatients() As DataTable
            Dim patientTable As DataTable = New DataTable()
            Dim resultReader As SqlDataReader = Nothing
            Dim command As SqlCommand = New SqlCommand("GetPatient", con)
            command.CommandType = CommandType.StoredProcedure

            Try
                con.Open()
                resultReader = command.ExecuteReader()
                patientTable.Load(resultReader)
                resultReader.Close()
                con.Close()
            Catch exception As Exception

                If resultReader IsNot Nothing OrElse con.State = ConnectionState.Open Then
                    resultReader.Close()
                    con.Close()
                End If
            End Try

            Return patientTable
        End Function
        Public Function AddPatient(ByVal ObjBO As PatientBO) As Integer
            Try
                Dim cmd As SqlCommand = New SqlCommand("spInsertPatient", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Name", ObjBO.Name)
                cmd.Parameters.AddWithValue("@NRIC", ObjBO.Address)
                cmd.Parameters.AddWithValue("@DateOfBirth", ObjBO.DateOfBirth)
                cmd.Parameters.AddWithValue("@PhoneNumber", ObjBO.PhoneNumber)
                cmd.Parameters.AddWithValue("@Picture", ObjBO.Picture)
                cmd.Parameters.AddWithValue("@Address", ObjBO.Address)
                con.Open()
                Dim Result As Integer = cmd.ExecuteNonQuery()
                cmd.Dispose()
                Return Result
            Catch
                Throw
            Finally
                con.Close()
                con.Dispose()
            End Try
        End Function

        Public Function UpdatePatient(ByVal ObjBO As PatientBO) As Integer
            Try
                Dim cmd As SqlCommand = New SqlCommand("spUpdatePatient", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@ID", ObjBO.ID)
                cmd.Parameters.AddWithValue("@Name", ObjBO.Name)
                cmd.Parameters.AddWithValue("@NRIC", ObjBO.NRIC)
                cmd.Parameters.AddWithValue("@DateOfBirth", ObjBO.DateOfBirth)
                cmd.Parameters.AddWithValue("@PhoneNumber", ObjBO.PhoneNumber)
                cmd.Parameters.AddWithValue("@Picture", ObjBO.Picture)
                cmd.Parameters.AddWithValue("@Address", ObjBO.Address)
                con.Open()
                Dim Result As Integer = cmd.ExecuteNonQuery()
                cmd.Dispose()
                Return Result
            Catch
                Throw
            Finally
                con.Close()
                con.Dispose()
            End Try
        End Function

        Public Function DeletePatient(ByVal ObjBO As PatientBO) As Integer
            Try
                Dim cmd As SqlCommand = New SqlCommand("spDeletePatient", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@ID", ObjBO.ID)
                con.Open()
                Dim Result As Integer = cmd.ExecuteNonQuery()
                cmd.Dispose()
                Return Result
            Catch
                Throw
            Finally
                con.Close()
                con.Dispose()
            End Try
        End Function

    End Class
End Namespace
