﻿Imports System.ServiceModel
Imports BusinessObject.BussinessObjects
Imports NcsWcfService.NcsWcfService

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IServiceTreatment" in both code and config file together.
<ServiceContract()>
Interface IServiceTreatment
    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Function GetTreatments() As List(Of Treatment)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub InsertOrUpdateTreatment(ByVal treatment As Treatment)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub DeleteTreatment(ByVal TreatmentId As Long)
End Interface

<Serializable>
Public Class Treatment
    <DataMember>
    Public ID As String
    <DataMember>
    Public ClinicId As String
    <DataMember>
    Public PatientId As String
    <DataMember>
    Public VisitDate As String
    <DataMember>
    Public Description As String
    <DataMember>
    Public Cost As String
End Class