﻿Imports System.ServiceModel
Imports BusinessObject
Imports BusinessObject.BussinessObjects

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IServicePatient" in both code and config file together.
<ServiceContract()>
Public Interface IServicePatient

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Function GetPatients() As List(Of Patient)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub InsertOrUpdatePatient(ByVal patient As Patient)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub DeletePatient(ByVal PatientId As Long)

End Interface

<Serializable>
Public Class Patient
    <DataMember>
    Public ID As String
    <DataMember>
    Public Name As String
    <DataMember>
    Public NRIC As String
    <DataMember>
    Public DateOfBirth As String
    <DataMember>
    Public PhoneNumber As String
    <DataMember>
    Public Picture As String
    <DataMember>
    Public Address As String
End Class