﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "ServicePatient" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select ServicePatient.svc or ServicePatient.svc.vb at the Solution Explorer and start debugging.
Imports System.Data.SqlClient
Imports BusinessObject.BussinessObjects

Public Class ServicePatient
    Implements IServicePatient
    Public Shared ConnectionString As String = ConfigurationManager.ConnectionStrings("NCS_IHISConnectionString").ConnectionString
    Public Sub InsertOrUpdatePatient(patient As Patient) Implements IServicePatient.InsertOrUpdatePatient
        Try
            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spInsertOrUpdatePatient", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", patient.ID))
                command.Parameters.Add(New SqlParameter("@Name", patient.Name))
                command.Parameters.Add(New SqlParameter("@NRIC", patient.NRIC))
                command.Parameters.Add(New SqlParameter("@DateOfBirth", patient.DateOfBirth))
                command.Parameters.Add(New SqlParameter("@PhoneNumber", patient.PhoneNumber))
                command.Parameters.Add(New SqlParameter("@Address", patient.Address))
                Dim result As Object = command.ExecuteScalar()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub

    Public Sub DeletePatient(ID As Long) Implements IServicePatient.DeletePatient
        Try

            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spDeletePatient", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", ID))
                Dim result As Integer = command.ExecuteNonQuery()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub

    'Public Function GetPatients() As List(Of Patient) Implements IServicePatient.GetPatients
    '    Throw New NotImplementedException()
    'End Function

    Public Function GetPatients() As List(Of Patient) Implements IServicePatient.GetPatients
        Dim patientList As List(Of Patient) = New List(Of Patient)()
        Dim resourceTable As DataTable = New DataTable()
        Dim resultReader As SqlDataReader = Nothing
        Dim connection As SqlConnection = New SqlConnection(ConnectionString)
        Dim command As SqlCommand = New SqlCommand("spGetPatient", connection)
        command.CommandType = CommandType.StoredProcedure

        Try
            connection.Open()
            resultReader = command.ExecuteReader()
            resourceTable.Load(resultReader)
            resultReader.Close()
            connection.Close()
            patientList = (From dr In resourceTable.Rows Select New Patient() With {
                .ID = dr("ID"),
                .Name = dr("Name").ToString(),
                .NRIC = dr("NRIC").ToString(),
                .DateOfBirth = dr("DateOfBirth").ToString(),
                .PhoneNumber = dr("PhoneNumber").ToString(),
                .Address = dr("Address").ToString()
            }).ToList()
        Catch exception As Exception

            If resultReader IsNot Nothing OrElse connection.State = ConnectionState.Open Then
                resultReader.Close()
                connection.Close()
            End If

            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try

        Return patientList
    End Function

End Class
