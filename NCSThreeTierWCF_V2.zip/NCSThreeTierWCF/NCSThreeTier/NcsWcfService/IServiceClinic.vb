﻿Imports System.ServiceModel
Imports BusinessObject.BussinessObjects
Imports NcsWcfService.NcsWcfService

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IServicePatient" in both code and config file together.
<ServiceContract()>
Public Interface IServiceClinic

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Function GetClinics() As List(Of Clinic)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub InsertOrUpdateClinic(ByVal clinic As Clinic)

    <OperationContract>
    <FaultContract(GetType(ExceptionMessage))>
    Sub DeleteClinic(ByVal ClinicId As Long)
End Interface

<Serializable>
Public Class Clinic
    <DataMember>
    Public ID As String
    <DataMember>
    Public Name As String
    <DataMember>
    Public PhoneNumber As String
    <DataMember>
    Public Address As String
End Class