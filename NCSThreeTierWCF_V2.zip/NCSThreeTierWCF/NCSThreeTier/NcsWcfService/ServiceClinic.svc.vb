﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "ServiceClinic" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select ServiceClinic.svc or ServicePatient.svc.vb at the Solution Explorer and start debugging.
Imports System.Data.SqlClient
Imports BusinessObject.BussinessObjects
Imports NcsWcfService.NcsWcfService

Public Class ServiceClinic
    Implements IServiceClinic
    Public Shared ConnectionString As String = ConfigurationManager.ConnectionStrings("NCS_IHISConnectionString").ConnectionString
    Public Sub InsertOrUpdateClinic(clinic As Clinic) Implements IServiceClinic.InsertOrUpdateClinic
        Try
            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spInsertOrUpdateClinic", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", clinic.ID))
                command.Parameters.Add(New SqlParameter("@Name", clinic.Name))
                command.Parameters.Add(New SqlParameter("@PhoneNumber", clinic.PhoneNumber))
                command.Parameters.Add(New SqlParameter("@Address", clinic.Address))
                Dim result As Object = command.ExecuteScalar()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub

    Public Sub DeleteClinic(ByVal ID As Long) Implements IServiceClinic.DeleteClinic
        Try

            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spDeleteClinic", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", ID))
                Dim result As Integer = command.ExecuteNonQuery()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub

    Public Function GetClinics() As List(Of Clinic) Implements IServiceClinic.GetClinics
        Dim clinicList As New List(Of Clinic)()
        Dim resourceTable As New DataTable()
        Dim resultReader As SqlDataReader = Nothing
        Dim connection As New SqlConnection(ConnectionString)
        Dim command As New SqlCommand("spGetClinic", connection)
        command.CommandType = CommandType.StoredProcedure

        Try
            connection.Open()
            resultReader = command.ExecuteReader()
            resourceTable.Load(resultReader)
            resultReader.Close()
            connection.Close()
            clinicList = (From dr In resourceTable.Rows Select New Clinic() With {
                .ID = dr("ID"),
                .Name = dr("Name").ToString(),
                .PhoneNumber = dr("PhoneNumber").ToString(),
                .Address = dr("Address").ToString()
            }).ToList()
        Catch exception As Exception

            If resultReader IsNot Nothing OrElse connection.State = ConnectionState.Open Then
                resultReader.Close()
                connection.Close()
            End If

            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try

        Return clinicList
    End Function

End Class
