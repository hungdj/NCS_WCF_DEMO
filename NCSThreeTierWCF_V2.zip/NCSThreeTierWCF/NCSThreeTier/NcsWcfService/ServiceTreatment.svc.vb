﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "ServicePatient" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select ServicePatient.svc or ServicePatient.svc.vb at the Solution Explorer and start debugging.
Imports System.Data.SqlClient
Imports BusinessObject.BussinessObjects
Imports NcsWcfService.NcsWcfService

Public Class ServiceTreatment
    Implements IServiceTreatment
    Public Shared ConnectionString As String = ConfigurationManager.ConnectionStrings("NCS_IHISConnectionString").ConnectionString
    Public Sub InsertOrUpdateTreatment(treatment As Treatment) Implements IServiceTreatment.InsertOrUpdateTreatment
        Try
            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spInsertOrUpdateTreatment", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", treatment.ID))
                command.Parameters.Add(New SqlParameter("@ClinicId", treatment.ClinicId))
                command.Parameters.Add(New SqlParameter("@PatientId", treatment.PatientId))
                command.Parameters.Add(New SqlParameter("@VisitDate", treatment.VisitDate))
                command.Parameters.Add(New SqlParameter("@Description", treatment.Description))
                command.Parameters.Add(New SqlParameter("@Cost", treatment.Cost))
                Dim result As Object = command.ExecuteScalar()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub

    Public Sub DeleteTreatment(ByVal ID As Long) Implements IServiceTreatment.DeleteTreatment
        Try

            Using connection As SqlConnection = New SqlConnection(ConnectionString)
                connection.Open()
                Dim command As SqlCommand = New SqlCommand("spDeleteTreatment", connection)
                command.CommandType = CommandType.StoredProcedure
                command.Parameters.Add(New SqlParameter("@ID", ID))
                Dim result As Integer = command.ExecuteNonQuery()
                connection.Close()
            End Using

        Catch exception As SqlException
            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try
    End Sub


    Public Function GetTreatments() As List(Of Treatment) Implements IServiceTreatment.GetTreatments
        Dim treatmentList As New List(Of Treatment)()
        Dim resourceTable As DataTable = New DataTable()
        Dim resultReader As SqlDataReader = Nothing
        Dim connection As SqlConnection = New SqlConnection(ConnectionString)
        Dim command As SqlCommand = New SqlCommand("spGetTreatment", connection)
        command.CommandType = CommandType.StoredProcedure

        Try
            connection.Open()
            resultReader = command.ExecuteReader()
            resourceTable.Load(resultReader)
            resultReader.Close()
            connection.Close()
            treatmentList = (From dr In resourceTable.Rows Select New Treatment() With {
                .ID = dr("ID"),
                .ClinicId = dr("ClinicId").ToString(),
                .PatientId = dr("PatientId").ToString(),
                .VisitDate = dr("VisitDate").ToString(),
                .Description = dr("Description").ToString(),
                .Cost = dr("Cost").ToString()
            }).ToList()
        Catch exception As Exception

            If resultReader IsNot Nothing OrElse connection.State = ConnectionState.Open Then
                resultReader.Close()
                connection.Close()
            End If

            Throw New FaultException(Of ExceptionMessage)(New ExceptionMessage(exception.Message))
        End Try

        Return treatmentList
    End Function

End Class
