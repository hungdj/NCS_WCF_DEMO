﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports BusinessObject.BussinessObjects
Imports DataAccess.DataAccess

Namespace BussinesslogicLayer
    Public Class PatientBL
        Public Function AddPatient(ByVal objUserBL As PatientBO) As Integer
            Try
                Dim objPatientDA As PatientDA = New PatientDA()
                Return objPatientDA.AddPatient(objUserBL)
            Catch
                Throw
            End Try
        End Function
        Public Function UpdatePatient(ByVal objUserBL As PatientBO) As Integer
            Try
                Dim objPatientDA As PatientDA = New PatientDA()
                Return objPatientDA.UpdatePatient(objUserBL)
            Catch
                Throw
            End Try
        End Function
        Public Function DeletePatient(ByVal objUserBL As PatientBO) As Integer
            Try
                Dim objPatientDA As PatientDA = New PatientDA()
                Return objPatientDA.DeletePatient(objUserBL)
            Catch
                Throw
            End Try
        End Function

        Public Function GetPatients() As DataTable
            Try
                Dim objPatientDA As PatientDA = New PatientDA()
                Return objPatientDA.GetPatients()
            Catch ex As Exception
                Throw
            End Try
        End Function

        Public Function GetPatients_List() As List(Of PatientBO)
            Dim objPatientDA As PatientDA = New PatientDA()
            Dim patientList As List(Of PatientBO) = objPatientDA.GetPatients_List()

            Return patientList
        End Function

    End Class
End Namespace
