﻿Imports System.Data.SqlClient
Imports System.Data
Public Class ClinicMaster
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            ResetClinic()
            BindClinics()
        End If
    End Sub
    Protected Sub BindClinics()
        Dim serviceClinic As New ServiceClinic.ServiceClinicClient()
        GridView1.DataSource = serviceClinic.GetClinics()
        GridView1.DataBind()
    End Sub

    Protected Sub ResetClinic()
        txtName.Text = ""
        txtPhoneNumber.Text = ""
        txtAddress.Text = ""
    End Sub

    Protected Sub btnAddClinic_Click(sender As Object, e As EventArgs) Handles btnAddClinic.Click
        If txtName.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter Name')", True)
        ElseIf txtPhoneNumber.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter PhoneNumber')", True)
        ElseIf txtAddress.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter Address')", True)
        Else
            Dim serviceClinic As New ServiceClinic.ServiceClinicClient()
            Dim clinic As New ServiceClinic.Clinic With {
                .ID = 0,
                .Name = txtName.Text,
                .PhoneNumber = txtPhoneNumber.Text,
                .Address = txtAddress.Text
            }
            serviceClinic.InsertOrUpdateClinic(clinic)

            ResetClinic()
            BindClinics()
        End If
    End Sub

    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim index As Integer = e.CommandArgument
        Dim cmdname As String = e.CommandName
        Dim pid As Integer = GridView1.Rows(index).Cells(0).Text
        ViewState("PID") = pid

        If e.CommandName = "pedit" Then
            txtName.Text = GridView1.Rows(index).Cells(1).Text
            txtPhoneNumber.Text = GridView1.Rows(index).Cells(2).Text
            txtAddress.Text = GridView1.Rows(index).Cells(3).Text
        Else
            Dim serviceClinic As New ServiceClinic.ServiceClinicClient()
            serviceClinic.DeleteClinic(pid)

            ResetClinic()
            BindClinics()
        End If
    End Sub

    Protected Sub btnSaveChange_Click(sender As Object, e As EventArgs) Handles btnSaveChange.Click
        Dim pid As Integer = ViewState("PID")
        Dim serviceClinic As New ServiceClinic.ServiceClinicClient()
        Dim clinic As New ServiceClinic.Clinic With {
                .ID = pid,
                .Name = txtName.Text,
                .PhoneNumber = txtPhoneNumber.Text,
                .Address = txtAddress.Text
            }

        serviceClinic.InsertOrUpdateClinic(clinic)

        BindClinics()
    End Sub
End Class