﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.BussinesslogicLayer
Imports BusinessObject.BussinessObjects
Imports System.Net
Imports System.Security.Cryptography
Imports System.ServiceModel.PeerResolvers

Public Class PatientMaster
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("NCS_IHISConnectionString").ConnectionString
    Dim cnn As New SqlConnection(constr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            ResetPatient()
            BindPatients()
        End If
    End Sub
    Protected Sub BindPatients()
        Dim servicePatient As New ServicePatient.ServicePatientClient()
        GridView1.DataSource = servicePatient.GetPatients()
        GridView1.DataBind()
    End Sub

    Protected Sub ResetPatient()
        txtName.Text = ""
        txtNRIC.Text = ""
        txtDateOfBirthday.Text = Date.Now()
        txtPhoneNumber.Text = ""
        txtAddress.Text = ""
    End Sub

    Protected Sub btnAddPatient_Click(sender As Object, e As EventArgs) Handles btnAddPatient.Click

        If txtName.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter Name')", True)
        ElseIf txtNRIC.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter NRIC')", True)
        ElseIf txtDateOfBirthday.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter DateOfBirthday')", True)
        ElseIf txtPhoneNumber.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter PhoneNumber')", True)
        ElseIf txtAddress.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter Address')", True)
        Else
            Dim servicePatient As New ServicePatient.ServicePatientClient()
            Dim patient As New ServicePatient.Patient With {
                .ID = 0,
                .Name = txtName.Text,
                .NRIC = txtNRIC.Text,
                .DateOfBirth = txtDateOfBirthday.Text,
                .PhoneNumber = txtPhoneNumber.Text,
                .Address = txtAddress.Text
            }
            servicePatient.InsertOrUpdatePatient(patient)

            ResetPatient()
            BindPatients()
        End If
    End Sub

    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim index As Integer = e.CommandArgument
        Dim cmdname As String = e.CommandName
        Dim pid As Integer = GridView1.Rows(index).Cells(0).Text
        ViewState("PID") = pid

        If e.CommandName = "pedit" Then
            txtName.Text = GridView1.Rows(index).Cells(1).Text
            txtNRIC.Text = GridView1.Rows(index).Cells(2).Text
            txtDateOfBirthday.Text = Date.Parse(GridView1.Rows(index).Cells(3).Text)
            txtPhoneNumber.Text = GridView1.Rows(index).Cells(4).Text
            txtAddress.Text = GridView1.Rows(index).Cells(5).Text
        Else
            Dim servicePatient As New ServicePatient.ServicePatientClient()
            servicePatient.DeletePatient(pid)

            ResetPatient()
            BindPatients()
        End If
    End Sub

    Protected Sub btnSaveChange_Click(sender As Object, e As EventArgs) Handles btnSaveChange.Click
        Dim pid As Integer = ViewState("PID")
        Dim servicePatient As New ServicePatient.ServicePatientClient()
        Dim patient As New ServicePatient.Patient With {
                .ID = pid,
                .Name = txtName.Text,
                .NRIC = txtNRIC.Text,
                .DateOfBirth = txtDateOfBirthday.Text,
                .PhoneNumber = txtPhoneNumber.Text,
                .Address = txtAddress.Text
            }

        servicePatient.InsertOrUpdatePatient(patient)

        ResetPatient()
        BindPatients()
    End Sub
End Class