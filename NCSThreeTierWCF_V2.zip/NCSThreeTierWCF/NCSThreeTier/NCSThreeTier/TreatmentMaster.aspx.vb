﻿Imports System.Data.SqlClient
Imports System.Data
Public Class TreatmentMaster
    Inherits System.Web.UI.Page
    Dim cnn As New SqlConnection("Data Source=DESKTOP-K4167OV;Initial Catalog=NCS_IHIS;Integrated Security=True")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            ResetTreatment()
            BindTreatments()
        End If
    End Sub
    Protected Sub BindTreatments()
        Dim serviceTreatment As New ServiceTreatment.ServiceTreatmentClient()
        GridView1.DataSource = serviceTreatment.GetTreatments()
        GridView1.DataBind()
    End Sub

    Protected Sub ResetTreatment()
        txtVisitDate.Text = Date.Now()
        txtDescription.Text = ""
        txtCost.Text = ""
    End Sub

    Protected Sub btnAddTreatment_Click(sender As Object, e As EventArgs) Handles btnAddTreatment.Click
        If txtVisitDate.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter Name')", True)
        ElseIf txtDescription.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter NRIC')", True)
        ElseIf txtCost.Text = "" Then
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "alert", "alert('Please Enter DateOfBirthday')", True)
        Else
            Dim serviceTreatment As New ServiceTreatment.ServiceTreatmentClient()
            Dim treatment As New ServiceTreatment.Treatment With {
                .ID = 0,
                .ClinicId = ddlClinicId.SelectedValue,
                .PatientId = ddlPatientId.SelectedValue,
                .VisitDate = txtVisitDate.Text,
                .Description = txtDescription.Text,
                .Cost = txtCost.Text
            }
            serviceTreatment.InsertOrUpdateTreatment(treatment)

            ResetTreatment()
            BindTreatments()
        End If

    End Sub

    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim index As Integer = e.CommandArgument
        Dim cmdname As String = e.CommandName
        Dim pid As Integer = GridView1.Rows(index).Cells(0).Text
        ViewState("PID") = pid

        If e.CommandName = "pedit" Then
            ddlClinicId.SelectedValue = GridView1.Rows(index).Cells(1).Text

            ddlPatientId.SelectedValue = GridView1.Rows(index).Cells(2).Text

            txtVisitDate.Text = Date.Parse(GridView1.Rows(index).Cells(3).Text)
            txtDescription.Text = GridView1.Rows(index).Cells(4).Text
            txtCost.Text = GridView1.Rows(index).Cells(5).Text
        Else
            Dim cmd As New SqlCommand
            cmd.CommandText = "DELETE FROM Treatments WHERE ID = " & pid
            cmd.Connection = cnn
            cnn.Open()
            cmd.ExecuteNonQuery()
            cnn.Close()

            BindTreatments()
        End If
    End Sub

    Protected Sub btnSaveChange_Click(sender As Object, e As EventArgs) Handles btnSaveChange.Click
        Dim pid As Integer = ViewState("PID")
        Dim cmd As New SqlCommand
        cmd.CommandText = "UPDATE Treatments SET ClinicId = '" & ddlClinicId.SelectedValue & "', PatientId = '" & ddlPatientId.SelectedValue & "', VisitDate = '" & txtVisitDate.Text _
        & "', Description = '" & txtDescription.Text & "', Cost = '" & txtCost.Text & "' WHERE ID = " & pid
        cmd.Connection = cnn
        cnn.Open()
        cmd.ExecuteNonQuery()
        cnn.Close()

        BindTreatments()
    End Sub
End Class